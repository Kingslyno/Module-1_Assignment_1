# The part is to load necessary library
library(dplyr)

# Sample data for 400 employees
set.seed(123)
employees <- data.frame(
  employee_id = 1:400,
  salary = sample(5000:30000, 400, replace = TRUE),
  gender = sample(c("Male", "Female"), 400, replace = TRUE)
)

# Initializing a column for employee level
employees$employee_level <- NA

# Test condition to generate a payslip
for (i in 1:nrow(employees)) {
  tryCatch({
    if (employees$salary[i] > 10000 && employees$salary[i] < 20000) {
      employees$employee_level[i] <- "A1"
    } else if (employees$salary[i] > 7500 && employees$salary[i] < 30000 && employees$gender[i] == "Female") {
      employees$employee_level[i] <- "A5-F"
    }
  }, error = function(e) {
    message(paste("Unable to process employee ID:", employees$employee_id[i], " - ", e$message))
  })
}

# View the updated employees data frame
head(employees)

